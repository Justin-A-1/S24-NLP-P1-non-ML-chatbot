# this file makes the knowledge base

# this file takes the partway cleaned up text files from folder clean_text_output_files
# it creates a large dict with keys for 17 US cities and 7 domestic tourism topics
# in addition to these, Austin has 5 additional keys for the 5 domestic tourism topics that are not 'beach' and 'mountain'
# total # of keys is 38; most but not all are used (LA is not used but is kept for future potential changes, a few Dallas ones are not used)
# at the end, the dict is pickled and saved to key_words_dict.pkl
 
import os
import nltk
import re
from nltk.tokenize import sent_tokenize
import pickle

# Get the directory of the current script
dir_path_curr_script = os.path.dirname(os.path.realpath(__file__))

# add clean_text_output_folder to path
clean_text_output_folder = os.path.join(dir_path_curr_script,'clean_text_output_files')
os.makedirs(clean_text_output_folder, exist_ok=True) #make sure the folder exists

key_cities_list = [ 
    'LA', 'Angeles', 'Vegas', 'York', 'Boston', 'Chicago', 'D. C.', 'Francisco', 'Orleans', 'Portland', 'Austin', 'Dallas', #top hits - city names # removed 'Washington' bc it was too ambigeous thus buggy (pulled up stuff other than the city)
    'Orlando', 'Miami', 'Denver', 'San Antonio', 'Houston' # manual adds - city names
]

key_topics_list = [
    'beach', 'mountain', 'music', 'party', 'museum', 'restaurant', 'bar' # top hits - key topics
    # manual adds - key topics #considered adding theme, romantic, hike, zoo, theater, and sports, but none of these had enough content
]

# dallas and austin have so much content that their content will be kept separate
key_topics_list_dallas = [item + '_dallas' for item in key_topics_list]
key_topics_list_austin = [item + '_austin' for item in key_topics_list]

key_words_list = key_cities_list + key_topics_list + key_topics_list_dallas + key_topics_list_austin

key_words_dict = {word: [] for word in key_words_list}

error_counter = 0
words_to_exclude = ['\n','fight','miss','please','Please','follow','member','Member','benefits','Benefits','Follow','We', 'our','Our','she','She','Jenna','Christine','Visit Austin','Kinsey','My','my',"We're",'we',"we're",'fly', 'flight','airport', 'Airport', 'Biden','Trump','Democrat','democrat','Republican','republican','No.','Washington.',"Washington's"]  # List of words to exclude
phone_pattern = r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'
zip_pattern = r'\d{5}(-\d{4})?'
final_iter = 1000 #I usually have fewer than 600, this is just a placeholder
for key_word in key_words_dict.keys():
    for iter in range(1, final_iter + 1):
        clean_text_output_file_name = f'clean_text_output_file_{iter}.txt'
        clean_text_output_file_path = os.path.join(clean_text_output_folder, clean_text_output_file_name)
        try:
        
            # open clean text file
            with open(clean_text_output_file_path, 'r', encoding='utf-8') as file:
                text = file.read()
                sent_tokens = sent_tokenize(text)
                sent_tokens = [sentence for sentence in sent_tokens if not re.search(phone_pattern, sentence)] # remove sentences containing phone numbers
                sent_tokens = [sentence for sentence in sent_tokens if not re.search(zip_pattern, sentence)] # remove sentences containing ZIP codes
                sent_tokens = [sentence for sentence in sent_tokens if not any(word in sentence for word in words_to_exclude)] # remove sentences containing words to exclude
                sent_tokens = [sentence for sentence in sent_tokens if not any(len(word) > 15 for word in sentence.split())] # remove sentences with long words (it's often an unreadable smush of multiple words)
                sent_tokens = [sentence for sentence in sent_tokens if not re.search(r'[^\s][A-Z]', sentence)] # remove sentences with capital letters preceded by any non-space char
                sent_tokens = [sentence for sentence in sent_tokens if len(sentence) < 175 and len(sentence) > 50] # remove sentences too long or too short (it's often a paragraph with improper spacing, or a little fragment)

                for sentence in sent_tokens:
                    if key_word in sentence:
                        if key_word in key_topics_list and any(city in sentence for city in key_cities_list if city not in ['Dallas', 'Austin']): # store a sentence under a key topic if it's connected to one of the key cities
                            key_words_dict[key_word].append(sentence)
                            #print(f'Key: {key_word} -- Sentence: {sentence}')
                        elif key_word in key_topics_list and 'Dallas' in sentence: # store a sentence under a key topic if it's connected to dallas
                            key_words_dict[key_word+'_dallas'].append(sentence)
                            #print(f'Key: {key_word}_dallas -- Sentence: {sentence}')
                        elif key_word in key_topics_list and 'Austin' in sentence: # store a sentence under a key topic if it's connected to austin
                            key_words_dict[key_word+'_austin'].append(sentence)
                            #print(f'Key: {key_word}_austin -- Sentence: {sentence}')
                        elif key_word in key_cities_list: # store a sentence under the key_word >> this will just store facts about all the major cities
                            key_words_dict[key_word].append(sentence)
                            #print(f'Key: {key_word} -- Sentence: {sentence}')

                # print(f'File {iter} iter finished, continuing...')
        except Exception as e:
            if error_counter < 0: # this can be adjusted if I'm looking for problems...
                #... but since I programmed this to loop through more files than are there, it will show a lot of errors
                #... even in a completely normal run
                print(f'Error reading clean file {iter}: {e}')
            error_counter += 1
            continue

print('printing dict content alphabetically by key:')
for key in sorted(key_words_dict.keys()):
    print(f'{key}:')
    for item in key_words_dict[key]:
        print(f' --- {item}')
    print()
    print()

pickle_file_path = os.path.join(dir_path_curr_script, 'key_words_dict.pkl')

with open(pickle_file_path, 'wb') as file:
    pickle.dump(key_words_dict,file)

print('DICTIONARY HAS BEEN PICKLED AND SAVED.\naeg_knowl_base_maker.py: PROGRAM TERMINATED.')