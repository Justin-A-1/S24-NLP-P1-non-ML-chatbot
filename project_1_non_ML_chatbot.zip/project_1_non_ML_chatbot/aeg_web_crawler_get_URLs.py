# aeg_web_crawler_get_URLs.py
# this code crawls the web starting from 6 google search result pages, usually getting about 300 total pages
# originally it was set up to where it had 3 original google search result pages, and it went deeper
# however, I found that deep searches quickly lost the focus of the USA, so I opted for a broader start but a shallower search
# so, this search terminates after 1 layer (it searches all the original pages, and all their links, then stops before losing focus)
from bs4 import BeautifulSoup
import requests
import os
from time import sleep

# crawler code was initially from Prof Mazidi's code

# Get the directory of the current script
dir_path_curr_script = os.path.dirname(os.path.realpath(__file__))

# STARTER URLs
# originally I used just 3 and my search went multiple layers deep
# but I found that it was difficult for the web crawler to maintain focus in deeper layers
# so instead I opted to have a *very* broad start (11 starting URLs) but make the crawl very shallow
# --- intentionally, the crawl only goes 1 layer deep, and only 2 links are permitted from each site in the 2nd layer...
#..... because I really didn't want the outliers on 2nd layer to dilute the data
# starter URLs are google searches for
# 1 - us top tourist cities
# 2 - us best tourist cities 
# 3 - us fun tourist cities
# 4 - us cool tourist cities
# 5 - us party tourist cities

# I added 3 more because they provide more breadth, but I felt that deeper layers really lost the focus I wanted on US domestic travel
# 6 - us fun cities
# 7 - us fun cities weekend trip
# 8 - us fun cities weekend vacation

# I added 3 more to provide more depth and conpensate for decreasing the depth even more (limiting links from the 2nd layer)
# 9 - us top vacation cities
# 10 - us best vacation cities
# 11 - us fun vacation cities

# 12 - added https://www.holidify.com/places/dallas/sightseeing-and-things-to-do.html for Dallas specifically later in the project because the options for dallas were otherwise very lacking
# 13 - added https://www.austintexas.org/austin-insider-blog/post/things-to-do-in-austin/ for Austin specifically because I wanted more options for Austin
starter_urls_list = [
'https://www.google.com/search?q=us+top+tourist+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn0-p5fHvwokv82a0X5XrdQgCPe1B0A%3A1709534084798&source=hp&ei=hGvlZYu7Ltz_p84P1PSDIA&iflsig=ANes7DEAAAAAZeV5lBxXzyYuqxKjPI7EoFHWhffOJFmq&ved=0ahUKEwiLjere_tmEAxXc_8kDHVT6AAQQ4dUDCA8&uact=5&oq=us+top+tourist+cities&gs_lp=Egdnd3Mtd2l6IhV1cyB0b3AgdG91cmlzdCBjaXRpZXMyBRAAGIAEMgYQABgWGB4yBhAAGBYYHjIGEAAYFhgeMgYQABgWGB4yBhAAGBYYHjIGEAAYFhgeMgYQABgWGB4yBhAAGBYYHjILEAAYgAQYigUYhgNIzCFQgglY5RhwAXgAkAEAmAGRAaAByw2qAQQxOS4yuAEDyAEA-AEBmAIWoAKzDqgCCsICBxAjGOoCGCfCAgoQIxiABBiKBRgnwgIEECMYJ8ICFBAuGIAEGIoFGJECGLEDGMcBGNEDwgILEAAYgAQYigUYkQLCAggQABiABBixA8ICCxAuGIAEGMcBGNEDwgIOEC4YgAQYsQMYxwEY0QPCAg4QLhiABBjHARivARiOBZgDCJIHBDE4LjQ&sclient=gws-wiz',
'https://www.google.com/search?q=us+best+tourist+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn09tCezcRXj-D_fyqANs9Jyj2fVwVg%3A1709534101497&ei=lWvlZaiLHuj9p84PvpWHgAI&ved=0ahUKEwjoqefm_tmEAxXo_skDHb7KASAQ4dUDCBA&uact=5&oq=us+best+tourist+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiFnVzIGJlc3QgdG91cmlzdCBjaXRpZXMyBhAAGAgYHjILEAAYgAQYigUYhgMyCxAAGIAEGIoFGIYDMgsQABiABBiKBRiGA0iyD1D0Ali2BXACeAGQAQCYAWSgAd0CqgEDMy4xuAEDyAEA-AEBmAIFoAK1AsICChAAGEcY1gQYsAPCAggQABgIGAcYHpgDAIgGAZAGCJIHAzMuMg&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+fun+tourist+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn086i5pDblMoJO3E52Ln82z_dtg2gA%3A1709534134660&ei=tmvlZd7uJ_zfp84Po4yPuAc&ved=0ahUKEwjeoc_2_tmEAxX878kDHSPGA3cQ4dUDCBA&uact=5&oq=us+fun+tourist+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiFXVzIGZ1biB0b3VyaXN0IGNpdGllczIIEAAYgAQYogQyCBAAGIAEGKIEMggQABiABBiiBDIIEAAYgAQYogRI7xZQ8QdY9hBwAngBkAEAmAGVAaABlAOqAQMzLjG4AQPIAQD4AQGYAgagAsUDwgIKEAAYRxjWBBiwA8ICBxAAGIAEGA3CAggQABgIGAcYHsICCBAAGAUYHhgNwgILEAAYgAQYigUYhgOYAwCIBgGQBgiSBwM1LjE&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+cool+tourist+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn09jjHWQJ1P_RZ2UtMIbxvJwe6dFlQ%3A1709534152084&ei=yGvlZYDbBK_fp84PleCCoAM&ved=0ahUKEwiA3_b-_tmEAxWv78kDHRWwADQQ4dUDCBA&uact=5&oq=us+cool+tourist+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiFnVzIGNvb2wgdG91cmlzdCBjaXRpZXMyCBAAGIAEGKIEMggQABiABBiiBEjjE1D5C1jNEHACeAGQAQCYAZABoAGYBKoBAzMuMrgBA8gBAPgBAZgCBqAC4QPCAgoQABhHGNYEGLADwgIHEAAYgAQYDcICCBAAGAUYHhgNwgILEAAYgAQYigUYhgOYAwCIBgGQBgiSBwMzLjM&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+party+tourist+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn092ZyTI_JgVTpkx-rS_dVxQPImWrA%3A1709534169845&ei=2WvlZcmdM6m4wN4PqbyTwA8&ved=0ahUKEwiJ7rKH_9mEAxUpHNAFHSneBPgQ4dUDCBA&uact=5&oq=us+party+tourist+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiF3VzIHBhcnR5IHRvdXJpc3QgY2l0aWVzMggQABiJBRiiBDIIEAAYgAQYogQyCBAAGIAEGKIESPoUUIgNWJsQcAJ4AZABAJgBmgGgAc0EqgEDMi4zuAEDyAEA-AEBmAIEoAKQAsICChAAGEcY1gQYsAOYAwCIBgGQBgiSBwMyLjI&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+fun+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn0-urqV9PETn8KryTRRMMDp8jr96Rg%3A1709534191297&ei=72vlZdfTEevep84PiLqHmAM&ved=0ahUKEwiXh9CR_9mEAxVr78kDHQjdATMQ4dUDCBA&uact=5&oq=us+fun+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiDXVzIGZ1biBjaXRpZXMyBRAAGIAEMggQABgIGAcYHjIIEAAYCBgHGB4yCBAAGAgYBxgeMgYQABgIGB4yBhAAGAgYHjIGEAAYCBgeMgYQABgIGB4yBhAAGAgYHjIGEAAYCBgeSIAYUJMIWNEKcAF4AZABAJgBV6AB8AGqAQEzuAEDyAEA-AEBmAIEoAKLAsICChAAGEcY1gQYsAPCAgYQABgHGB6YAwCIBgGQBgiSBwE0&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+fun+cities+weekend+trip&sca_esv=0aade082d29507cb&sxsrf=ACQVn0_kWhbWJxhnAWpPhuUiiT3HrysJTg%3A1709534209631&ei=AWzlZc-TJpW1wN4Plb2EiAY&ved=0ahUKEwiPmK-a_9mEAxWVGtAFHZUeAWEQ4dUDCBA&uact=5&oq=us+fun+cities+weekend+trip&gs_lp=Egxnd3Mtd2l6LXNlcnAiGnVzIGZ1biBjaXRpZXMgd2Vla2VuZCB0cmlwMgUQIRigATIFECEYoAEyBRAhGKABMgUQIRifBUjRHlD4BVj6F3ADeAGQAQCYAYIBoAGAC6oBBDExLjS4AQPIAQD4AQGYAhKgAtoLwgIKEAAYRxjWBBiwA8ICBhAAGBYYHsICCxAAGIAEGIoFGIYDwgIHECEYChigAZgDAIgGAZAGCJIHBDEzLjU&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+fun+cities+weekend+vacation&sca_esv=0aade082d29507cb&sxsrf=ACQVn0-K8kt-L2J7CguYFIVUjgCyUe3Exg%3A1709534230841&ei=FmzlZcT-MqzbwN4P3P6E2Ao&ved=0ahUKEwjE4b2k_9mEAxWsLdAFHVw_AasQ4dUDCBA&uact=5&oq=us+fun+cities+weekend+vacation&gs_lp=Egxnd3Mtd2l6LXNlcnAiHnVzIGZ1biBjaXRpZXMgd2Vla2VuZCB2YWNhdGlvbjIFECEYoAEyBRAhGKABMgUQIRigATIFECEYoAEyBRAhGJ8FMgUQIRifBTIFECEYnwUyBRAhGJ8FMgUQIRifBUjeDVDuBFjPC3ACeAGQAQCYAYQBoAGsBqoBAzQuNLgBA8gBAPgBAZgCCqAC-wbCAgoQABhHGNYEGLADwgIGEAAYFhgewgILEAAYgAQYigUYhgOYAwCIBgGQBgiSBwM2LjQ&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+top+vacation+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn0_nShtQ8tgtvyTpTYkkGxoAPdXIgg%3A1709534244883&ei=JGzlZdfKNcTgp84Pw6mWmA4&ved=0ahUKEwjX7Jar_9mEAxVE8MkDHcOUBeMQ4dUDCBA&uact=5&oq=us+top+vacation+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiFnVzIHRvcCB2YWNhdGlvbiBjaXRpZXMyBhAAGBYYHjIGEAAYFhgeMgYQABgWGB4yBhAAGBYYHjIGEAAYFhgeMgYQABgWGB4yBhAAGBYYHjIGEAAYFhgeMgYQABgWGB4yBhAAGBYYHki0MVDHB1ihHHABeAGQAQCYAWGgAe8LqgECMTm4AQPIAQD4AQGYAhSgAtQMwgIKEAAYRxjWBBiwA8ICChAjGIAEGIoFGCfCAgoQABiABBiKBRhDwgILEAAYgAQYigUYkQLCAg0QABiABBiKBRhDGLEDwgIKEAAYgAQYFBiHAsICChAuGIAEGIoFGEPCAgUQABiABMICCBAAGBYYHhgKwgILEAAYgAQYigUYhgOYAwCIBgGQBgiSBwQxNy4z&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+best+vacation+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn0_1JRTOVS8AtESXgacC_Ejo1OMXBQ%3A1709534263418&ei=N2zlZYSPGZC5wN4P8aeTuAo&ved=0ahUKEwjEhoK0_9mEAxWQHNAFHfHTBKcQ4dUDCBA&uact=5&oq=us+best+vacation+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiF3VzIGJlc3QgdmFjYXRpb24gY2l0aWVzMgYQABgIGB4yBhAAGAgYHjIGEAAYCBgeMgYQABgIGB4yBhAAGAgYHjIGEAAYCBgeMgYQABgIGB4yBhAAGAgYHjIGEAAYCBgeMgYQABgIGB5I-xBQyAJY9ARwAngBkAEAmAFsoAHEAqoBAzMuMbgBA8gBAPgBAZgCBaACoALCAgoQABhHGNYEGLADwgIIEAAYCBgHGB6YAwCIBgGQBgiSBwM0LjE&sclient=gws-wiz-serp',
'https://www.google.com/search?q=us+fun+vacation+cities&sca_esv=0aade082d29507cb&sxsrf=ACQVn0_4Tr_o4WmmNd_Oi0ggvpA6nalIXQ%3A1709534276010&ei=RGzlZdsVvrunzg-1wIm4AQ&ved=0ahUKEwjbx4K6_9mEAxW-3ckDHTVgAhcQ4dUDCBA&uact=5&oq=us+fun+vacation+cities&gs_lp=Egxnd3Mtd2l6LXNlcnAiFnVzIGZ1biB2YWNhdGlvbiBjaXRpZXMyBhAAGAgYHjILEAAYgAQYigUYhgMyCxAAGIAEGIoFGIYDMgsQABiABBiKBRiGA0jfEFCkCViPDnACeAGQAQCYAVqgAcYCqgEBNLgBA8gBAPgBAZgCBaACoALCAgoQABhHGNYEGLADwgIHEAAYgAQYDcICCBAAGAUYHhgNwgIIEAAYCBgeGA3CAggQABgIGAcYHpgDAIgGAZAGCJIHAzQuMQ&sclient=gws-wiz-serp',
'https://www.holidify.com/places/dallas/sightseeing-and-things-to-do.html',
'https://www.austintexas.org/austin-insider-blog/post/things-to-do-in-austin/'
]

# primary exclusion list
# possible adds to exclusion list: 'redirect', 'out', 'external', 'track'
read_exclusion_list = [
    'facebook', 'twitter', 'instagram', 
    'login', 'signup', 'register', 'subscribe', 
    'policy', 'policies', 'privacy', 'terms', 'disclaimer', 
    'ads', 'sponsor', 'affiliate', 
    'podcast', 'video','audio', 
    'download', '.pdf', '.docx', '.xlsx',
    'comment', 'user', 'forum',
    'faq', 'help',  #not excluded: 'tag'
    'cookie',
    'cart','checkout',
    'cgi-bin','.jpg','.jpeg','.png','.gif',
    'accounts', 'support', 'maps', 'google', 'careers', 'contact-us', 'aaa', #these were found in apparently irrelevant result URLs
    'gallery', 'galleries', 'about-us','profile', #these were found in apparently irrelevant result URLs
    'buzzfeed',
    'about','press','quizzes', 'shopping', 'celebrity', 'bestoftheinternet','signin','tvandmovies', #these were found in apparently irrelevant result URLs - in this case these were originally found on buzzfeed
    'coupons','stocks','indices','commodities','subscription', 'ethics', 'who-we-are', 'currencies','linkedin','markets','breakup', #these were found in apparently irrelevant result URLs - in this case from businessinsider.com
    'usnews', 'tripadvisor', #sites that do not like to be crawled
    'author','contact',
    'pinterest', 'youtube', 'snapchat', #additional sites to exclude
    'africa','asia','australia','europe','india','china','japan','paris','middle-east','england','wales','canada','south-america','mexico','oceania', #additional key words to exclude
    'hotels',#additional key words to exclude
    'product','brand','shop','agreements', 'privacy',
    'agreement','disclosure', #additional key words to exclude
]

# this language excluder was removed because these little two character strings
# were found to pop up frequently in unrelated URLs, removing up to 95% of URLs in some instances
# 'es', 'th', and 'id', for spanish, thai, and indonesian, 
# are not excluded bc of potential presence in relevant english words/URLs
'''read_exclusion_list_language_indicators = [
    'ar', 'zh', 'zh-tw', 'nl', 'fr', 'de', 'el', 'hi', 'hu', 'ja', 'ko',
    'ms', 'pl', 'pt', 'ro', 'ru', 'sk', 'sv', 'tr', 'vi'
]'''

#this list is for sites that do not like to be crawled
'''write_exclusion_list = [
]'''

# checking if the URL contains any item on the exclusion list
def present_on_read_exclusion_lists(url):
    return any(item in url for item in read_exclusion_list) # + read_exclusion_list_language_indicators)

# cleaning up the start of the URL
def clean_url_start(url):
    start_patterns = ['/url?q=','/redirect?', '/track?', '/out?', '/go?', '/goto?', '/r?', '/ref?']
    for pattern in start_patterns:
        if url.startswith(pattern):
            url = url[len(pattern):]
            break # some URLs will have multiple start patterns but it's not too common
    return url

# removing hashes ###
def clean_url_hash(url):
    if '#' in url:
        hash_index = url.find('#')
        url = url[:hash_index] #remove anything after the hash->#
    return url

# removing &
def clean_url_and(url):
    if '&' in url:
        and_index = url.find('&')
        url = url[:and_index] #remove anything after the &
    return url

# removing %23
def clean_url_percent23(url):
    if '%23' in url:
        url = url.split('%23', 1)[0]
    return url

# removing certain query patterns #this was excluded because it was possibly contributing to some problem
# but it did not appear to be solving any core problem
'''def clean_url_query_patterns(url):
    query_patterns = ['utm_source=', 'session=', 'token=', 'page=', 'sort=', 'filter=', 'lang=', 'locale=']
    for param in query_patterns:
        if param in url:
            base_url, query_string = url.split('?', 1)  # Split URL into base and query(or queries)
            query_parts = query_string.split('&')
            query_parts = [part for part in query_parts if not any(part.startswith(p) for p in query_patterns)]
            url = base_url + '?' + '&'.join(query_parts) if query_parts else base_url
            break
    return url'''

# variable starter_urls_list primarily exists to clarify what (and how many) we start with
# when we're ready to process, stick it in urls_list
urls_list = starter_urls_list.copy()
seen_urls_set = set(urls_list)

# arrays to store responses, data, soups
responses = []
datas = []
soups = []

# write urls to a file
# initially from Prof Mazidi's code
counter1 = 0
write_url_list_position = 0
layer_marked_TF = [True, False] # the end of the starter_urls is known, the end of the second layer is not yet known
layer_end = [len(starter_urls_list), 0]
max_links_from_read_position = 1000 # this is a place holder - this number isn't supposed to limit anything when set to 1000
urls_file_path = os.path.join(dir_path_curr_script,'urls.txt')


with open(urls_file_path, 'w') as urls_file:
    for read_position in range(300): 
        print('START read_position:', read_position, f'\n---- Reading URL: {urls_list[read_position]}')
        success = False
        # VVV originally this was for more than just 1 attempt, but I found that it typically did not succeed on subsequent attempts so I went with just 1
        for attempt in range(1): 
            try:
                response = requests.get(urls_list[read_position])
                success = True
                break
            except requests.exceptions.ConnectionError as e:
                print(f"Connection error: {e}")
                sleep(1.25 ** attempt)  # backoff
            except requests.exceptions.Timeout as e:
                # Specific handling for timeout exceptions
                print(f"Request timed out: {e}")
                sleep(1.25 ** attempt)  # backoff
            except requests.exceptions.RequestException as e:
                # A base class for catching all other requests-related exceptions
                print(f"Error during request: {e}")
                sleep(1.25 ** attempt)  # backoff

        if not success:
            print(f"All attempts failed for read_position {read_position}. Moving to next URL.")
            responses.append(0)
            datas.append(0)
            soups.append(0)
            continue
        data = response.text
        soup = BeautifulSoup(data, features="html.parser")

        # add next item
        responses.append(response)
        datas.append(data)
        soups.append(soup)

        links_from_read_position = 0
        # print(f"DEBUG: read_position={read_position}, len(starter_urls_list)={len(starter_urls_list)}, layer_marked_TF[1]={layer_marked_TF[1]}")
        if read_position >= len(starter_urls_list) and layer_marked_TF[1] == False:
            layer_end[1] = write_url_list_position # mark the end of the second layer
            layer_marked_TF[1] = True
            max_links_from_read_position = 2 # starting on the second layer, there is now a max link from each url iteration
            # print('\n\nMAX LINKS FROM READ POS IS SET \n\n\n\n')
        if layer_end[1] and read_position > layer_end[1]:
            print('REACHED END OF LAYER 1. TERMINATING WEB CRAWLER.')
            break
        for link in soups[read_position].find_all('a'):
            link_str = str(link.get('href'))
            #print(counter1, ":", link_str)
            #counter1 += 1
            if not present_on_read_exclusion_lists(link_str):
                link_str = clean_url_hash(link_str)
                link_str = clean_url_and(link_str)
                link_str = clean_url_start(link_str)
                link_str = clean_url_percent23(link_str)
                # link_str = clean_url_query_patterns(link_str)
                if link_str.startswith('//'):
                    link_str = 'http:' + link_str
                if link_str not in seen_urls_set:
                    seen_urls_set.add(link_str)
                    if link_str.startswith('http'):
                        urls_file.write(link_str + '\n')
                        urls_list.append(link_str)
                        print(write_url_list_position, ":", link_str)
                        write_url_list_position += 1
                        links_from_read_position += 1
                        #print(f'DEBUG: {write_url_list_position}: links_from_read_position: {links_from_read_position}, max_links_from_read_position: {max_links_from_read_position}')
                        if links_from_read_position > max_links_from_read_position:
                            break
        print('END read_position:', read_position, '\n\n')

#for i in range(1,len(urls_list)):
#    print(i,":",urls_list[i])



# end of program
print("CRAWLER TERMINATED")