# aeg_web_text_cleaner.py
# this file does an initial clean of the raw_text files
# the files are already somewhat clean since they are initially created using soup.get_text()
# this file removes URLs, emails, and most white space
# any number of '\n' is replaced by '\n\n' which makes the cleaned up text divided into paragraphs and very readable
# prob the most important thing this code does is remove paragraphs with character count < 175...
# ... this removes lots of internet random stuff that isn't actually useful for the program
# ... it is helpful that this cutoff occurs before stopwords are removed
# ... other than captions and other random stuff, most things actually written by a person are preserved through this
import os
import re
from html import unescape

# Get the directory of the current script
dir_path_curr_script = os.path.dirname(os.path.realpath(__file__))
raw_text_output_folder = os.path.join(dir_path_curr_script,'raw_text_output_files')

clean_text_output_folder = os.path.join(dir_path_curr_script,'clean_text_output_files')
os.makedirs(clean_text_output_folder, exist_ok=True) #make sure the output folder exists

final_iter = 1000 #I usually have fewer than 600, this is just a placeholder
error_counter = 0
for iter in range(1, final_iter + 1):
    raw_text_output_file_path = os.path.join(raw_text_output_folder,f'raw_text_output_file_{iter}.txt')

    if not os.path.exists(raw_text_output_file_path):
        if error_counter < 0: # this can be adjusted if I'm looking for problems...
            #... but since I programmed this to loop through more files than are there, it will show a lot of errors
            #... even in a completely normal run
            print(f'Raw text file {iter} not found, continuing...')
        error_counter += 1
        continue
    try:
        # open raw text file
        with open(raw_text_output_file_path, 'r', encoding='utf-8') as file:
            text = file.read()

            #remove the first line of the raw text file, since it just lists the URL
            lines = text.split('\n')
            del lines[0]
            text = '\n'.join(lines)

            # Decode HTML entities. 
            # soup.get_text() should have already done most of this, but in case it missed something this double checks
            text = unescape(text)

            # Replace email addresses with a placeholder (or remove)
            text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '<email>', text)

            # Remove URLs
            text = re.sub(r'http\S+', '', text)

            # Remove HTML tags
            text = re.sub(r'<[^>]+>', '', text)

            # Replace "." with ". " (adding spacees after periods which are not followed by spaces)
            text = re.sub(r'\.(?![\s])', '. ', text)

            #remove white space
            #text = ' '.join(text.split())

            # Split text into paragraphs, trim extra whitespace within each paragraph,
            # remove paragraphs that are fewer than 175 charaacters
            # and then rejoin with double newlines to preserve paragraph breaks.
            paragraphs = text.split('\n')
            cleaned_paragraphs = [' '.join(paragraph.split()) for paragraph in paragraphs]
            cleaned_paragraphs_v2 = [paragraph for paragraph in cleaned_paragraphs if len(paragraph) >= 175]
            text = '\n\n'.join(cleaned_paragraphs_v2)

            # save cleaned text to file
            clean_text_output_file_name = f'clean_text_output_file_{iter}.txt'
            clean_text_output_file_path = os.path.join(clean_text_output_folder, clean_text_output_file_name)
            with open(clean_text_output_file_path, 'w', encoding='utf-8') as output_file:
                output_file.write(text)
                print(f'Raw text file {iter} cleaned and saved to new file, continuing...')
    except Exception as e:
        print(f'Error reading and cleaning raw file {iter}: {e}')
        continue

#print('1 not found at the end is fine.')
print('INITIAL TEXT CLEANING: PROGRAM TERMINATED.')