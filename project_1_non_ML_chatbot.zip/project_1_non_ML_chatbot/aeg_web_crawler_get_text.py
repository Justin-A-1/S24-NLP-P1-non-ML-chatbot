# aeg_web_crawler_get_text.py
# this code gets raw text from the previously acquired URLs
# it's already a little cleaned up since I use text = soup.get_text()
from bs4 import BeautifulSoup
import requests
import os

# Get the directory of the current script
dir_path_curr_script = os.path.dirname(os.path.realpath(__file__))
urls_file_path = os.path.join(dir_path_curr_script,'urls.txt')

# prepare output file path
raw_text_output_folder = os.path.join(dir_path_curr_script,'raw_text_output_files')
os.makedirs(raw_text_output_folder, exist_ok=True) #make sure the output folder exists

with open(urls_file_path, 'r', encoding='utf-8') as file:
    line_counter = 0

    for line in file:
        url = line.strip()

        #fetch the content from url
        try:
            response = requests.get(url)
            html_content = response.text

            soup = BeautifulSoup(html_content, 'html.parser')
            text = soup.get_text()

            # save raw text to file
            raw_text_output_file_name = f'raw_text_output_file_{line_counter+1}.txt'
            raw_text_output_file_path = os.path.join(raw_text_output_folder, raw_text_output_file_name)
            with open(raw_text_output_file_path, 'w', encoding='utf-8') as output_file:
                output_file.write(f"U R L: {url}\n{text}\n\n")

            print(f'Successfully souped and output #{line_counter+1}, {url}')
        except requests.exceptions.RequestException as e:
            print(f'Request failed for {url}: {e}')

        line_counter += 1

        if line_counter == 1000: # I currently have 600 urls, so this is just a failsafe/useful for testing
            break

print('COMPLETE: aeg_web_crawler_get_text.py has successfully run and terminated.')