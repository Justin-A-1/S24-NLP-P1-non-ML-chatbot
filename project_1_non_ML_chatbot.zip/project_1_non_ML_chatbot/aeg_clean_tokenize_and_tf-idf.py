# 
from sklearn.feature_extraction.text import TfidfVectorizer
import os
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
#import string
import spacy

nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Initialize the lemmatizer and get English stopwords
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))
nlp_spacy = spacy.load('en_core_web_sm')

# I tried manually removing non-city frequent words but that just didn't work at all
# tokens_to_remove = { }

# Get the directory of the current script
dir_path_curr_script = os.path.dirname(os.path.realpath(__file__))

# add clean_text_output_folder to path
clean_text_output_folder = os.path.join(dir_path_curr_script,'clean_text_output_files')
os.makedirs(clean_text_output_folder, exist_ok=True) #make sure the folder exists

texts_non_city_included = []
texts_locations_only = []
error_counter = 0
final_iter = 1000 #I usually have fewer than 350, this is just a placeholder
for iter in range(1, final_iter + 1):
    clean_text_output_file_name = f'clean_text_output_file_{iter}.txt'
    clean_text_output_file_path = os.path.join(clean_text_output_folder, clean_text_output_file_name)
    try:
        # open clean text file
        with open(clean_text_output_file_path, 'r', encoding='utf-8') as file:
            text = file.read()
            text = text.lower() # lowercase the text
            tokens = word_tokenize(text)
            tokens = [word for word in tokens if word.isalpha()] # remove punctuation
            tokens = [word for word in tokens if word not in stop_words] # remove stopwords
            #tokens = [word for word in tokens if word not in tokens_to_remove] #I tried manually removing non-city frequent words but that just didn't work at all # remove undesired diluting words
            lemmatized_tokens = [lemmatizer.lemmatize(word) for word in tokens]

            text = ' '.join(lemmatized_tokens) # rejoin tokens
            texts_non_city_included.append(text)

            # filtering to get only the locations
            text_spacied = nlp_spacy(text) # process text with spacy
            city_tokens = [ent.text for ent in text_spacied.ents if ent.label_ in ['LOC']]
            text = ' '.join(city_tokens)
            texts_locations_only.append(text)
            # print(f'File {iter} successfully added to the corpus, continuing...')
    except Exception as e:
        if error_counter < 0: # this can be adjusted if I'm looking for problems...
            #... but since I programmed this to loop through more files than are there, it will show a lot of errors
            #... even in a completely normal run
            print(f'Error reading clean file {iter}: {e}')
        error_counter += 1
        continue

# initialize and fit the vectorizer
vectorizer = TfidfVectorizer()
tfidf_matrixV1 = vectorizer.fit_transform(texts_non_city_included)

# get feature names to use as indices
feature_namesV1 = vectorizer.get_feature_names_out()

# sum tf-idf scores for each feature across all documents
sums = tfidf_matrixV1.sum(axis=0)

# Connect term to its sums tf-idf score
dataV1 = []
for column, term in enumerate(feature_namesV1):
    dataV1.append((term, sums[0, column]))

# Sort terms by score
ranked_termsV1 = sorted(dataV1, key=lambda x: x[1], reverse=True)

# Output the top 300 terms
print('TF-IDF LIST INCLUDING NON-LOCATION WORDS:')
for term, score in ranked_termsV1[:300]:
    print(f"{term}: {score}")
print('END OF TF-IDF LIST INCLUDING NON-LOCATION WORDS\n\n')

# initialize and fit the vectorizer
vectorizer = TfidfVectorizer()
tfidf_matrixV2 = vectorizer.fit_transform(texts_non_city_included)

# get feature names to use as indices
feature_namesV2 = vectorizer.get_feature_names_out()

# sum tf-idf scores for each feature across all documents
sums = tfidf_matrixV2.sum(axis=0)

# Connect term to its sums tf-idf score
dataV2 = []
for column, term in enumerate(feature_namesV2):
    dataV2.append((term, sums[0, column]))

# Sort terms by score
ranked_termsV2 = sorted(dataV2, key=lambda x: x[1], reverse=True)

# Output the top 300 terms
print('TF-IDF LIST EXCLUDING NON-LOCATION WORDS:')
for term, score in ranked_termsV2[:300]:
    print(f"{term}: {score}")
print('END OF TF-IDF LIST EXCLUDING NON-LOCATION WORDS\n\n')