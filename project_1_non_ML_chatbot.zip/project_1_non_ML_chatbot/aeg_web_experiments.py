import urllib
from urllib import request # for opening and reading URLs
# from urllib import error # for exceptions raised by URL requests
# from urllib import parse # to parse URLs
# from urllib import robotparser # to parse robots.txt files
from bs4 import BeautifulSoup
import re

# reads and prints the gutenberg book
# from Prof Mazidi's github
''' url = "http://www.gutenberg.org/files/2554/2554-0.txt"
with request.urlopen(url) as f:
    raw = f.read().decode('utf-8-sig')
print('len=', len(raw))
print(raw[:100]) '''

# this gets a bunch of random non-content stuff
# from Prof Mazidi's github
''' url = 'https://en.wikipedia.org/wiki/Las_Vegas'
html = request.urlopen(url).read().decode('utf8')
print(html[:1000]) ''' 

# initially from Prof Mazidi's github
url = 'https://en.wikipedia.org/wiki/Las_Vegas'
html = request.urlopen(url).read().decode('utf8')
soup = BeautifulSoup(html, features="html.parser")

# kill all script and style elements
# initially from Prof Mazidi's github
for script in soup(["script", "style"]):
    script.extract()    # rip it out

# get text
# initially from Prof Mazidi's github
text = soup.get_text()
# print(text[:200]) #this prints way too much blank/white space

# print text chunks, bypassing the white space
# initially from Prof Mazidi's github
text_chunks = [chunk for chunk in text.splitlines() if not re.match(r'^\s*$', chunk)]
for i, chunk in enumerate(text_chunks):
    print(i+1, chunk)
    if i >= 1:
        break

# print paragraphs
# initially from Prof Mazidi's github
'''for p in soup.select('p'):
    print(p)'''

counter = 0
for link in soup.find_all('a'):
    counter += 1
    if counter > 10:
        break
    print(link.get('href'))